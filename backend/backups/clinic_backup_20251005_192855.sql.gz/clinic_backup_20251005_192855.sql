--
-- PostgreSQL database dump
--

\restrict FTcZUFCOhq21p5I7otxfjY0OHK97BMRyEEN1brlDNCwwXXkIcyFrgTi24mJXya1

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-10-05 16:28:56 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 232 (class 1255 OID 16542)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 16446)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    duration integer DEFAULT 30 NOT NULL,
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 16425)
-- Name: consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    chief_complaint text NOT NULL,
    diagnosis text,
    treatment_plan text,
    notes text,
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 16506)
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    patient_id uuid NOT NULL,
    invoice_number character varying(50) NOT NULL,
    date date NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    subtotal numeric(10,2) DEFAULT 0.00 NOT NULL,
    tax_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    total_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    payment_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    payment_method character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 219 (class 1259 OID 16468)
-- Name: medicines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medicines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    generic_name character varying(100) NOT NULL,
    dosage_form character varying(50) NOT NULL,
    strength character varying(50) NOT NULL,
    manufacturer character varying(100) NOT NULL,
    batch_number character varying(50),
    expiry_date date,
    current_stock integer DEFAULT 0 NOT NULL,
    minimum_stock integer DEFAULT 0 NOT NULL,
    unit_price numeric(10,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16412)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    patient_number character varying(20) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(10) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(255),
    address text,
    emergency_contact character varying(100),
    emergency_phone character varying(15),
    blood_type character varying(10),
    allergies jsonb DEFAULT '[]'::jsonb,
    medical_history text,
    insurance_type character varying(50),
    insurance_number character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 16479)
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prescriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    consultation_id uuid,
    medicines jsonb DEFAULT '[]'::jsonb NOT NULL,
    instructions text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 215 (class 1259 OID 16396)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    department character varying(100) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3528 (class 0 OID 16446)
-- Dependencies: 218
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, doctor_id, date, "time", duration, status, notes, created_at, updated_at) FROM stdin;
950e8400-e29b-41d4-a716-446655440001	650e8400-e29b-41d4-a716-446655440001	550e8400-e29b-41d4-a716-446655440004	2024-01-20	09:00:00	30	scheduled	Follow-up appointment	2025-10-04 15:56:52.006982+00	2025-10-04 15:56:52.006982+00
950e8400-e29b-41d4-a716-446655440002	650e8400-e29b-41d4-a716-446655440002	550e8400-e29b-41d4-a716-446655440004	2024-01-25	11:00:00	45	scheduled	Annual checkup	2025-10-04 15:56:52.006982+00	2025-10-04 15:56:52.006982+00
\.


--
-- TOC entry 3527 (class 0 OID 16425)
-- Dependencies: 217
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultations (id, patient_id, doctor_id, date, "time", chief_complaint, diagnosis, treatment_plan, notes, status, created_at, updated_at) FROM stdin;
850e8400-e29b-41d4-a716-446655440001	650e8400-e29b-41d4-a716-446655440001	550e8400-e29b-41d4-a716-446655440004	2024-01-15	10:00:00	Headache	Tension headache	Rest and pain medication	Patient reports stress at work	completed	2025-10-04 15:56:51.987842+00	2025-10-04 15:56:51.987842+00
850e8400-e29b-41d4-a716-446655440002	650e8400-e29b-41d4-a716-446655440002	550e8400-e29b-41d4-a716-446655440004	2024-01-16	14:00:00	Fever and cough	Common cold	Rest, fluids, and over-the-counter medication	Patient has been symptomatic for 2 days	completed	2025-10-04 15:56:51.987842+00	2025-10-04 15:56:51.987842+00
\.


--
-- TOC entry 3531 (class 0 OID 16506)
-- Dependencies: 221
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, patient_id, invoice_number, date, items, subtotal, tax_amount, total_amount, payment_status, payment_method, created_at, updated_at) FROM stdin;
b50e8400-e29b-41d4-a716-446655440001	650e8400-e29b-41d4-a716-446655440001	INV-2024-001	2024-01-15	[{"total": 50.00, "quantity": 1, "unit_price": 50.00, "description": "Consultation Fee"}, {"total": 77.00, "quantity": 14, "unit_price": 5.50, "description": "Medication"}]	127.00	12.70	139.70	paid	cash	2025-10-04 15:56:52.041975+00	2025-10-04 15:56:52.041975+00
b50e8400-e29b-41d4-a716-446655440002	650e8400-e29b-41d4-a716-446655440002	INV-2024-002	2024-01-16	[{"total": 30.00, "quantity": 1, "unit_price": 30.00, "description": "Follow-up Consultation"}]	30.00	3.00	33.00	pending	\N	2025-10-04 15:56:52.041975+00	2025-10-04 15:56:52.041975+00
\.


--
-- TOC entry 3529 (class 0 OID 16468)
-- Dependencies: 219
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medicines (id, name, generic_name, dosage_form, strength, manufacturer, batch_number, expiry_date, current_stock, minimum_stock, unit_price, created_at, updated_at) FROM stdin;
750e8400-e29b-41d4-a716-446655440001	Paracetamol	Acetaminophen	Tablet	500mg	PharmaCorp	BATCH001	2025-12-31	100	20	5.50	2025-10-04 15:56:51.972851+00	2025-10-04 15:56:51.972851+00
750e8400-e29b-41d4-a716-446655440002	Ibuprofen	Ibuprofen	Tablet	400mg	MediCorp	BATCH002	2025-11-30	50	10	8.75	2025-10-04 15:56:51.972851+00	2025-10-04 15:56:51.972851+00
750e8400-e29b-41d4-a716-446655440003	Amoxicillin	Amoxicillin	Capsule	250mg	AntibioCorp	BATCH003	2025-10-15	75	15	12.00	2025-10-04 15:56:51.972851+00	2025-10-04 15:56:51.972851+00
\.


--
-- TOC entry 3526 (class 0 OID 16412)
-- Dependencies: 216
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, patient_number, first_name, last_name, date_of_birth, gender, phone, email, address, emergency_contact, emergency_phone, blood_type, allergies, medical_history, insurance_type, insurance_number, created_at, updated_at) FROM stdin;
650e8400-e29b-41d4-a716-446655440001	P001	John	Doe	1990-01-01	Male	1234567890	john.doe@email.com	123 Main St, City	Jane Doe	0987654321	O+	["Penicillin"]	No significant history	Private	INS123456	2025-10-04 15:56:51.955969+00	2025-10-04 15:56:51.955969+00
650e8400-e29b-41d4-a716-446655440002	P002	Jane	Smith	1985-05-15	Female	1234567891	jane.smith@email.com	456 Oak Ave, City	John Smith	0987654322	A+	[]	Diabetes Type 2	Public	PUB789012	2025-10-04 15:56:51.955969+00	2025-10-04 15:56:51.955969+00
650e8400-e29b-41d4-a716-446655440003	P003	Bob	Johnson	1980-03-20	Male	1234567892	bob.johnson@email.com	789 Pine St, City	Alice Johnson	0987654323	B+	[]	Hypertension	Private	INS345678	2025-10-04 15:56:51.955969+00	2025-10-04 15:56:51.955969+00
\.


--
-- TOC entry 3530 (class 0 OID 16479)
-- Dependencies: 220
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prescriptions (id, patient_id, doctor_id, consultation_id, medicines, instructions, status, created_at, updated_at) FROM stdin;
a50e8400-e29b-41d4-a716-446655440001	650e8400-e29b-41d4-a716-446655440001	550e8400-e29b-41d4-a716-446655440004	850e8400-e29b-41d4-a716-446655440001	[{"dosage": "500mg", "duration": "7 days", "quantity": 14, "frequency": "Twice daily", "medicine_id": "750e8400-e29b-41d4-a716-446655440001", "medicine_name": "Paracetamol"}]	Take with food. Complete the full course.	active	2025-10-04 15:56:52.023166+00	2025-10-04 15:56:52.023166+00
a50e8400-e29b-41d4-a716-446655440002	650e8400-e29b-41d4-a716-446655440002	550e8400-e29b-41d4-a716-446655440004	850e8400-e29b-41d4-a716-446655440002	[{"dosage": "400mg", "duration": "5 days", "quantity": 15, "frequency": "Three times daily", "medicine_id": "750e8400-e29b-41d4-a716-446655440002", "medicine_name": "Ibuprofen"}]	Take with food. Do not exceed recommended dose.	active	2025-10-04 15:56:52.023166+00	2025-10-04 15:56:52.023166+00
\.


--
-- TOC entry 3525 (class 0 OID 16396)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, role, name, department, permissions, is_active, created_at, updated_at) FROM stdin;
550e8400-e29b-41d4-a716-446655440001	admin	admin@clinic.com	$argon2id$v=19$m=19456,t=2,p=1$dGVzdC1zYWx0$test-hash	admin	System Administrator	Administration	["all"]	t	2025-10-04 15:56:51.93715+00	2025-10-04 15:56:51.93715+00
550e8400-e29b-41d4-a716-446655440002	receptionist	receptionist@clinic.com	$argon2id$v=19$m=19456,t=2,p=1$dGVzdC1zYWx0$test-hash	receptionist	Reception Staff	Reception	["patients:read", "patients:write", "appointments:read", "appointments:write"]	t	2025-10-04 15:56:51.93715+00	2025-10-04 15:56:51.93715+00
550e8400-e29b-41d4-a716-446655440003	nurse	nurse@clinic.com	$argon2id$v=19$m=19456,t=2,p=1$dGVzdC1zYWx0$test-hash	nurse	Nursing Staff	Nursing	["patients:read", "consultations:read", "consultations:write"]	t	2025-10-04 15:56:51.93715+00	2025-10-04 15:56:51.93715+00
550e8400-e29b-41d4-a716-446655440004	clinician	clinician@clinic.com	$argon2id$v=19$m=19456,t=2,p=1$dGVzdC1zYWx0$test-hash	clinician	Medical Doctor	Medical	["patients:read", "consultations:read", "consultations:write", "prescriptions:write"]	t	2025-10-04 15:56:51.93715+00	2025-10-04 15:56:51.93715+00
\.


--
-- TOC entry 3351 (class 2606 OID 16457)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 3346 (class 2606 OID 16435)
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- TOC entry 3365 (class 2606 OID 16522)
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- TOC entry 3367 (class 2606 OID 16520)
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- TOC entry 3357 (class 2606 OID 16478)
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- TOC entry 3342 (class 2606 OID 16424)
-- Name: patients patients_patient_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_patient_number_key UNIQUE (patient_number);


--
-- TOC entry 3344 (class 2606 OID 16422)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 3361 (class 2606 OID 16490)
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 3333 (class 2606 OID 16411)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3335 (class 2606 OID 16407)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3337 (class 2606 OID 16409)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3352 (class 1259 OID 16536)
-- Name: idx_appointments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_date ON public.appointments USING btree (date);


--
-- TOC entry 3353 (class 1259 OID 16535)
-- Name: idx_appointments_doctor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_doctor_id ON public.appointments USING btree (doctor_id);


--
-- TOC entry 3354 (class 1259 OID 16534)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 3347 (class 1259 OID 16533)
-- Name: idx_consultations_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_consultations_date ON public.consultations USING btree (date);


--
-- TOC entry 3348 (class 1259 OID 16532)
-- Name: idx_consultations_doctor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_consultations_doctor_id ON public.consultations USING btree (doctor_id);


--
-- TOC entry 3349 (class 1259 OID 16531)
-- Name: idx_consultations_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_consultations_patient_id ON public.consultations USING btree (patient_id);


--
-- TOC entry 3362 (class 1259 OID 16541)
-- Name: idx_invoices_invoice_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- TOC entry 3363 (class 1259 OID 16540)
-- Name: idx_invoices_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_patient_id ON public.invoices USING btree (patient_id);


--
-- TOC entry 3355 (class 1259 OID 16537)
-- Name: idx_medicines_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medicines_name ON public.medicines USING btree (name);


--
-- TOC entry 3338 (class 1259 OID 16529)
-- Name: idx_patients_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_name ON public.patients USING btree (first_name, last_name);


--
-- TOC entry 3339 (class 1259 OID 16528)
-- Name: idx_patients_patient_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_patient_number ON public.patients USING btree (patient_number);


--
-- TOC entry 3340 (class 1259 OID 16530)
-- Name: idx_patients_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_phone ON public.patients USING btree (phone);


--
-- TOC entry 3358 (class 1259 OID 16539)
-- Name: idx_prescriptions_doctor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prescriptions_doctor_id ON public.prescriptions USING btree (doctor_id);


--
-- TOC entry 3359 (class 1259 OID 16538)
-- Name: idx_prescriptions_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prescriptions_patient_id ON public.prescriptions USING btree (patient_id);


--
-- TOC entry 3379 (class 2620 OID 16546)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3378 (class 2620 OID 16545)
-- Name: consultations update_consultations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_consultations_updated_at BEFORE UPDATE ON public.consultations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3382 (class 2620 OID 16549)
-- Name: invoices update_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3380 (class 2620 OID 16547)
-- Name: medicines update_medicines_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medicines_updated_at BEFORE UPDATE ON public.medicines FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3377 (class 2620 OID 16544)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3381 (class 2620 OID 16548)
-- Name: prescriptions update_prescriptions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_prescriptions_updated_at BEFORE UPDATE ON public.prescriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3376 (class 2620 OID 16543)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3370 (class 2606 OID 16463)
-- Name: appointments appointments_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3371 (class 2606 OID 16458)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 3368 (class 2606 OID 16441)
-- Name: consultations consultations_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3369 (class 2606 OID 16436)
-- Name: consultations consultations_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 3375 (class 2606 OID 16523)
-- Name: invoices invoices_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 3372 (class 2606 OID 16501)
-- Name: prescriptions prescriptions_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id) ON DELETE SET NULL;


--
-- TOC entry 3373 (class 2606 OID 16496)
-- Name: prescriptions prescriptions_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3374 (class 2606 OID 16491)
-- Name: prescriptions prescriptions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


-- Completed on 2025-10-05 16:28:56 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict FTcZUFCOhq21p5I7otxfjY0OHK97BMRyEEN1brlDNCwwXXkIcyFrgTi24mJXya1

